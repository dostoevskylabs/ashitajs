const { ipcMain } = require('electron');
ipcMain.on('asynchronous-message', (event, arg) => {
  console.log(arg);
  event.reply('asynchronous-reply', {
  	type: 'async-reply',
  	content: {}
  });
})

ipcMain.on('synchronous-message', (event, arg) => {
  console.log(arg);
  event.returnValue = {
  	type: 'sync-reply',
  	content: {}
  };
})